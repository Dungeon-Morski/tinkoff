<?php $__env->startSection('content'); ?>
    <div class="main_section  w-full">
        <div class="container min-h-full flex">
            <div class=" grow flex justify-between gap-[45px]">
                <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
                <div class="section_info flex flex-col">
                    <h1 class="text-center">Оплата платежа</h1>
                    <p class="payment_comment text-center">Переведите указанную сумму на реквизиты кассира из формы
                        ниже</p>
                    <div class="payment_info">
                        <div class="flex flex-col justify-center items-center">
                            <div class="time_info flex justify-center items-center">
                                <p>Осталось времени: <span class="payment_time">30:00</span></p>
                            </div>
                            <div class="payment_cart">
                                <div class="cart_info flex flex-col gap-[22px]">

                                    <img class="cart_img" src="<?php echo e(asset('sources/images/'.$requisite->bank)); ?>.svg')}}" alt="qiwi">

                                    <div class="flex flex-col gap-[5px]">
                                        <p class="a_number">Номер счета</p>
                                        <div class="flex items-center gap-1">
                                            <p class="number"><?php echo e($requisite->requisites); ?></p>
                                            <button class="copyBtn">
                                                <img data-clipboard-target="#number"
                                                     class="copy_img cursor-pointer"
                                                     src="<?php echo e(asset('sources/icons/solar_copy-bold.svg')); ?>">
                                            </button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="sum_info flex justify-center gap-2">

                                <p>К оплате</p>
                                <span><?php echo e($amount); ?> ₽</span>

                            </div>
                            <a href="" class="success text-center">Я оплатил</a>
                            <a href="" class="cancel text-center">
                                Отменить операцию
                            </a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/payment.js']); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\new_tinkoff\resources\views/payment.blade.php ENDPATH**/ ?>