<?php $__env->startSection('content'); ?>
    <div class="main_section  w-full">
        <div class="container min-h-full flex">
            <div class=" grow flex justify-between gap-[45px]">
                <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
                <div class="section_info flex flex-col">
                    <h1>Вывод средств</h1>

                    <div class="withdraw_block">
                        <form action="<?php echo e(route('withdrawPost')); ?>" method="POST" class="">
                            <?php echo csrf_field(); ?>

                            <div class="flex flex-col gap-[15px] ">
                                <div>

                                    <select name="type" id="">
                                        <option value="">Выберите способ</option>
                                        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($method->title); ?>"><?php echo e($method->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="flex flex-col gap-[5px]">
                                    <p>Номер счёта:</p>
                                    <input type="text" id="invoice_number" placeholder="Введите номер счёта">
                                </div>

                                <div class="flex flex-col gap-[5px]">
                                    <p>Сумма:</p>
                                    <input type="number" max="<?php echo e($user->balance); ?>" id="invoice_number" name="summ" placeholder="От 10$ до <?php echo e($user->balance); ?>$">
                                </div>
                                <button type="submit">Вывести средства</button>
                            </div>
                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\new_tinkoff\resources\views/withdrawBalance.blade.php ENDPATH**/ ?>