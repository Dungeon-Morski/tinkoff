<?php $__env->startSection('content'); ?>
    <div class="main_section  w-full">
        <div class="container flex">
            <div class="w-full flex justify-between gap-[5px] md:gap-[45px] block flex-col relative md:flex-row ">
                <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
                <div class="section_info">
                    <h1>Здравствуйте, <?php echo e($user->login); ?></h1>
                    <div class="capital_info flex flex-col sm:flex-row gap-[20px] lg:gap-[45px] justify-between">
                        <div class="flex flex-col sm:flex-row gap-[20px] w-full lg:gap-[45px]">
                            <div class="balance_block">
                                <div class="flex gap-[10px] items-center">
                                    <div class="dollar"><span>$</span></div>
                                    <p class="balance">Общий баланс в $</p>
                                </div>
                                <p class="balance_count"><?php echo e($user->balance); ?> $</p>
                            </div>
                            <div class="profit_block">
                                <div class="flex gap-[10px] items-center">
                                    <div class="percent"><span>%</span></div>
                                    <p class="profit">Общий доход в %</p>
                                </div>
                                <p class="balance_count"><?php echo e($user->balance / 50 * 100); ?></p>
                            </div>
                        </div>
                        <div class="flex items-center justify-center gap-4">
                            <a href="<?php echo e(route('refill-balance')); ?>" class="ref_balance_btn">Пополнить баланс</a>
                            <button class="support_btn block sm:hidden">
                                <span>Поддержка</span>
                                <img src="<?php echo e(asset('sources/icons/support-icon.svg')); ?>" alt="support-icon">
                            </button>
                        </div>
                    </div>
                    <div class="stats">
                        <h2>Статистика профиля</h2>
                        <canvas class="mt-4" id="bar-chart-grouped" width="800" height="450"></canvas>
                    </div>
                </div>
                <div class="newses">
                    <h3 class="p-0 md:pl-[15px] ">Новости</h3>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>
                    <a href="" class="news">
                        <p class="new_title">В Минтрансе ответили на прогноз о повышении цен на авиабилеты до 40%</p>
                        <p class="new_category">Бизнес, <span class="new_datetime">10:01</span></p>
                    </a>


                </div>
            </div>
        </div>
    </div>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/invoice.js']); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nikit\PhpstormProjects\tinkoff\resources\views/invoice.blade.php ENDPATH**/ ?>