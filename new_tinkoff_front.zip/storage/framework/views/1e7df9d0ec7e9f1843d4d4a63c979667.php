<?php $__env->startSection('content'); ?>
    <div class="main_section w-full">
        <div class="depositOverlayBlock hidden">
            <div class="overlay">
            </div>
            <div class="modal_content">
                <form action="">
                    <div>
                        <label for=""></label>
                        <input id="deposit-amount" type="number" name="summ" placeholder="Введите сумму пополнения">
                    </div>
                    <button type="button" class="deposit-btn">Продолжить</button>
                </form>
            </div>
        </div>
        <div class="container flex h-full">
            <div class=" grow flex justify-between gap-[45px]">
                <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
                <div class="section_info flex flex-col">
                    <h1>Пополнить баланс</h1>

                    <div class="replenishments">
                        <?php $__currentLoopData = $requisites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($requisite->min_deposit > $user->balance ): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                        <div class="sec_card">

                            <div class="card_avatar_block flex gap-2 items-center">
                                <div class="avatar_wrapper">
                                    <img class="avatar" src="<?php echo e(asset('sources/images/avatar2.png')); ?>" alt="avatar2">
                                </div>
                                <p class="nickname"><?php echo e($requisite['owner'] ?? 'Артур Васильей'); ?></p>
                            </div>

                            <div class="card_info flex gap-4 justify-between  items-center mt-[12px] ">

                                <div class="flex flex-row md:flex-col gap-[20px]  w-full md:w-auto">
                                    <div class="flex gap-[10px]">
                                        <p>10 ордеров</p>
                                        <p>100.00% выполнено</p>
                                    </div>
                                    <div class="flex items-center">
                                        <img src="<?php echo e(asset('sources/icons/thumbs-up-fill.svg')); ?>" alt="thumbs-up-fill">
                                        <p>100%</p></div>
                                </div>
                                <div class="flex  items-center gap-1 self-start">
                                    <p class="summ"><?php echo e($requisite->rate); ?></p>
                                    <span> RUB</span>
                                </div>
                                <div class="flex  flex-col gap-[5px] self-start">
                                    <p>3, 302.65 USDT</p>
                                    <p>₽304.700.00 - ₽304.700.00</p>
                                </div>
                                <div class="bank_info">
                                    <p class="bank border-l-2 pl-2 sber"><?php echo e($requisite->bank); ?></p>
                                </div>


                                <button  data-id="<?php echo e($requisite->id); ?>" class="paymentBtn">Пополнить</button>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

            </div>
        </div>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/refill.js']); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nikit\PhpstormProjects\tinkoff\resources\views/refillBalance.blade.php ENDPATH**/ ?>